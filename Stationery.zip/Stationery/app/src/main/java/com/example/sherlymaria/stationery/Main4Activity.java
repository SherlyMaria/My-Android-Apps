package com.example.sherlymaria.stationery;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class Main4Activity extends AppCompatActivity {
    private Button not;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        not = (Button) findViewById(R.id.not);
        not.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {
                Uri g=Uri.parse("geo:37.7749,-122.4194");
                Intent intent = new Intent(Intent.ACTION_VIEW,g);
                intent.setPackage("com.google.android.apps.maps");
                Intent intent1 = new Intent(Intent.ACTION_DIAL);
                intent1.setData(Uri.parse("tel:8555811539"));
                PendingIntent pIntent = PendingIntent.getActivity(Main4Activity.this,
                        0, intent, 0);

                PendingIntent qIntent = PendingIntent.getActivity(Main4Activity.this,
                        0, intent1, 0);

                Notification noti = new Notification.Builder(Main4Activity.this)
                        .setTicker("Ticker")
                        .setContentTitle("CONGRATULATIONS!")
                        .setContentText("You have selected pens.")
                        .setSmallIcon(R.drawable.a1)
                        .addAction(R.drawable.i1, "Cart", pIntent)
                        .addAction(R.drawable.i2, "Contact", qIntent)
                        .setContentIntent(pIntent)
                        .setContentIntent(qIntent).getNotification();
                noti.flags = Notification.FLAG_AUTO_CANCEL;
                NotificationManager nm = (NotificationManager)
                        getSystemService(NOTIFICATION_SERVICE);
                nm.notify(0, noti);
            }
        });



    }
}
